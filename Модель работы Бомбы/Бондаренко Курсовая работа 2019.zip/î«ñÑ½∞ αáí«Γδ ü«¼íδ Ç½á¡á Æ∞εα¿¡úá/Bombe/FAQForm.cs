﻿using System;
using System.Windows.Forms;

namespace Bombe
{
    /// <summary>
    /// Form contains main info to use the app
    /// </summary>
    public partial class FAQForm : Form
    {
        public FAQForm()
        {
            InitializeComponent();
        }
    }
}
